# ExamPrep — Bangladesh Admission Exam Companion

A full native Android app (Kotlin) built for admission-exam prep: app blocker,
study/sleep/gym tracker, exam countdowns, routine alarms, notes, Do Not
Disturb automation, focus sessions, syllabus checklists, mock-test score
tracking, and streaks.

## How to open this in Acode

1. Copy the whole `ExamPrep` folder onto your phone (e.g. into `Internal
   storage/ExamPrep`).
2. In Acode, install the **Android Builder** plugin (Settings → Plugins →
   search "Android Builder").
3. Open the `ExamPrep` folder as a project in Acode.
4. Use Android Builder's **Build → Debug APK** to compile. First build will
   download Gradle + dependencies, so do it on Wi-Fi.
5. Install the generated `.apk` from `app/build/outputs/apk/debug/`.

If Android Builder ever fails on a specific Gradle/AGP version mismatch,
open `build.gradle` (root) and `app/build.gradle` and lower the
`com.android.application` / Kotlin plugin versions to whatever Android
Builder's bundled Gradle supports — the app code itself doesn't depend on
a specific AGP version.

## First-run setup (do this once, inside the app)

The app cannot request these three permissions through a normal popup —
Android requires you to grant them manually in Settings. The **Home** and
**Blocker** tabs have buttons that jump straight to each screen:

1. **Accessibility service** — Settings → Accessibility → ExamPrep → turn
   on. This is what allows the app blocker to detect and block apps.
2. **Do Not Disturb access** — lets Study Mode silence notifications
   automatically.
3. **Usage access** (optional, reserved for future stats) — Settings →
   Apps → Special access → Usage access.
4. On Android 12+, also allow **"Alarms & reminders"** for exact alarms if
   prompted, so routine alarms fire on time.

## Feature map

| Feature | Where | Notes |
|---|---|---|
| App blocker | Blocker tab | AccessibilityService sends you Home if you open a blocked app while Study Mode is on |
| Study/Sleep/Gym tracker | Tracker tab | Logs stored in Room (SQLite); weekly bar chart of study minutes |
| Exam countdowns | Exams tab | Add exam name/university/date; daily 8 AM notification with days left |
| Daily routine + alarms | Routine tab | Real `AlarmManager` alarms, repeat by day of week, full-screen ring screen |
| Notes | Notes tab | Simple subject-tagged notes, stored locally |
| Do Not Disturb | Home + Blocker tab | Auto-enables when Study Mode turns on |
| Focus session (Pomodoro) | Home tab | 25/50-min buttons auto-enable blocker + DND, auto-disable when done |
| Weekly study analytics | Tracker tab | Bar chart, last 7 days |
| Syllabus checklist | Tap an exam → Exam detail | Per-exam topic checklist with progress count |
| Mock test score log | Exam detail | Log scores, see running average % |
| Streak counter | Home tab | Increments once per calendar day you log study time |
| Boot persistence | Automatic | Alarms are rescheduled after phone restart |

## Architecture

- **Kotlin + View Binding**, single-activity-per-screen where needed,
  Fragments + BottomNavigationView for the 6 main tabs.
- **Room** database (`AppDatabase`) — all data is local, no server, no
  account needed.
- **SharedPreferences** (`Prefs.kt`) mirrors the blocked-app list and
  Study Mode flag so the Accessibility Service can read them
  synchronously without touching Room from a system callback thread.
- **WorkManager** for the once-daily exam countdown notification.
- **AlarmManager** (`setAlarmClock`) for routine alarms — most reliable
  type for exact-time alarms across OEM battery optimizers.

## Known limitations / things to harden later

- The app blocker uses `GLOBAL_ACTION_HOME` (kicks you to the home
  screen) rather than a full overlay lock screen — simpler and needs no
  extra `SYSTEM_ALERT_WINDOW` permission, but a determined user can still
  reopen the app immediately after being kicked out.
- No cloud backup/sync — everything lives in the phone's local database.
  Uninstalling the app deletes your data.
- Some OEMs (Xiaomi, Vivo, Oppo, Realme) aggressively kill background
  services/alarms. If alarms feel unreliable, also enable "Autostart" /
  disable battery optimization for ExamPrep in your phone's own settings.
