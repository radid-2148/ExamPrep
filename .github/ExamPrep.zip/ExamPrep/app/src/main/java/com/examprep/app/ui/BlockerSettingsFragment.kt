package com.examprep.app.ui

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.examprep.app.databinding.FragmentBlockerSettingsBinding
import com.examprep.app.util.DndHelper
import com.examprep.app.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BlockerSettingsFragment : Fragment() {

    private var _binding: FragmentBlockerSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: InstalledAppAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBlockerSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val context = requireContext()
        val pm = context.packageManager

        adapter = InstalledAppAdapter(pm, onToggle = { packageName, blocked ->
            if (blocked) Prefs.addBlockedApp(context, packageName)
            else Prefs.removeBlockedApp(context, packageName)
        })
        binding.recyclerApps.layoutManager = LinearLayoutManager(context)
        binding.recyclerApps.adapter = adapter

        binding.switchDndWithStudy.isChecked = Prefs.shouldEnableDndWithStudy(context)
        binding.switchDndWithStudy.setOnCheckedChangeListener { _, checked ->
            Prefs.setEnableDndWithStudy(context, checked)
        }

        binding.buttonAccessibilitySettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.buttonDndSettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        binding.buttonUsageAccessSettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        loadInstalledApps(pm)
        updatePermissionStatus(context)
    }

    override fun onResume() {
        super.onResume()
        if (_binding != null) updatePermissionStatus(requireContext())
    }

    private fun updatePermissionStatus(context: android.content.Context) {
        val dndGranted = DndHelper.hasDndAccess(context)
        binding.textDndStatus.text = if (dndGranted) "Do Not Disturb access: granted \u2705" else "Do Not Disturb access: not granted \u26A0\uFE0F"
    }

    private fun loadInstalledApps(pm: PackageManager) {
        viewLifecycleOwner.lifecycleScope.launch {
            val rows = withContext(Dispatchers.IO) {
                val ownPackage = requireContext().packageName
                pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    .filter { app ->
                        app.packageName != ownPackage &&
                            (app.flags and ApplicationInfo.FLAG_SYSTEM == 0 || pm.getLaunchIntentForPackage(app.packageName) != null)
                    }
                    .mapNotNull { app ->
                        if (pm.getLaunchIntentForPackage(app.packageName) == null) return@mapNotNull null
                        InstalledAppRow(app, app.loadLabel(pm).toString(), app.packageName)
                    }
                    .sortedBy { it.label.lowercase() }
            }
            adapter.submitList(rows, Prefs.getBlockedApps(requireContext()))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
