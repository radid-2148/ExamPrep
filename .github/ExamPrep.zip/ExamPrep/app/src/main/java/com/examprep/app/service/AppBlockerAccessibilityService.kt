package com.examprep.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import com.examprep.app.util.Prefs

/**
 * Watches which app comes to the foreground. If Study Mode is on and the
 * foreground app is in the blocked list, it sends the user back to the
 * Home screen instead of letting them open it.
 *
 * Requires the user to manually enable this service once under:
 * Settings > Accessibility > Installed apps > ExamPrep
 */
class AppBlockerAccessibilityService : AccessibilityService() {

    private var lastBlockedPackage: String? = null
    private var lastBlockTime = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return

        if (!Prefs.isStudyModeOn(applicationContext)) return

        val blocked = Prefs.getBlockedApps(applicationContext)
        if (packageName in blocked) {
            val now = System.currentTimeMillis()
            // avoid spamming home-press/toast if events fire repeatedly for the same app
            if (packageName == lastBlockedPackage && now - lastBlockTime < 1500) return
            lastBlockedPackage = packageName
            lastBlockTime = now

            performGlobalAction(GLOBAL_ACTION_HOME)
            Toast.makeText(
                applicationContext,
                "Blocked during study mode \u2013 stay focused! \uD83D\uDCDA",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onInterrupt() {
        // no-op
    }
}
