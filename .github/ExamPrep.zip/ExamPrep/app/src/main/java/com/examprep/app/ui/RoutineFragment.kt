package com.examprep.app.ui

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.examprep.app.data.AppDatabase
import com.examprep.app.data.RoutineItem
import com.examprep.app.databinding.DialogAddRoutineBinding
import com.examprep.app.databinding.FragmentRoutineBinding
import com.examprep.app.util.AlarmScheduler
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.random.Random

class RoutineFragment : Fragment() {

    private var _binding: FragmentRoutineBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: RoutineAdapter

    private val dayLabels = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRoutineBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val context = requireContext()
        val db = AppDatabase.getInstance(context)

        adapter = RoutineAdapter(
            onToggle = { item, enabled ->
                viewLifecycleOwner.lifecycleScope.launch {
                    val updated = item.copy(alarmEnabled = enabled)
                    db.routineItemDao().update(updated)
                    if (enabled) AlarmScheduler.schedule(context, updated)
                    else AlarmScheduler.cancel(context, updated)
                }
            },
            onLongClick = { item ->
                AlertDialog.Builder(context)
                    .setTitle("Delete '${item.title}'?")
                    .setPositiveButton("Delete") { _, _ ->
                        AlarmScheduler.cancel(context, item)
                        viewLifecycleOwner.lifecycleScope.launch { db.routineItemDao().delete(item) }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )
        binding.recyclerRoutine.layoutManager = LinearLayoutManager(context)
        binding.recyclerRoutine.adapter = adapter

        db.routineItemDao().getAll().observe(viewLifecycleOwner) { items ->
            adapter.submitList(items)
            binding.textEmptyRoutine.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.fabAddRoutine.setOnClickListener { showAddRoutineDialog(db) }
    }

    private fun showAddRoutineDialog(db: AppDatabase) {
        val context = requireContext()
        val dialogBinding = DialogAddRoutineBinding.inflate(LayoutInflater.from(context))
        var pickedHour = 7
        var pickedMinute = 0
        val selectedDays = mutableSetOf<Int>() // Calendar.SUNDAY=1..SATURDAY=7

        // Build day-of-week toggle chips
        dayLabels.forEachIndexed { index, label ->
            val dayNumber = index + 1
            val chip = com.google.android.material.chip.Chip(context)
            chip.text = label
            chip.isCheckable = true
            chip.setOnCheckedChangeListener { _, checked ->
                if (checked) selectedDays.add(dayNumber) else selectedDays.remove(dayNumber)
            }
            dialogBinding.chipGroupDays.addView(chip)
        }

        dialogBinding.buttonPickTime.setOnClickListener {
            TimePickerDialog(context, { _, hour, minute ->
                pickedHour = hour
                pickedMinute = minute
                dialogBinding.buttonPickTime.text = String.format("%02d:%02d", hour, minute)
            }, pickedHour, pickedMinute, false).show()
        }

        AlertDialog.Builder(context)
            .setTitle("Add routine item")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val title = dialogBinding.editRoutineTitle.text.toString().trim()
                if (title.isEmpty()) {
                    Toast.makeText(context, "Enter a title", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val daysCsv = if (selectedDays.isEmpty())
                    (1..7).joinToString(",") else selectedDays.sorted().joinToString(",")

                viewLifecycleOwner.lifecycleScope.launch {
                    val item = RoutineItem(
                        title = title,
                        hour = pickedHour,
                        minute = pickedMinute,
                        daysOfWeek = daysCsv,
                        alarmEnabled = true,
                        requestCode = Random.nextInt(1, 999999)
                    )
                    val id = db.routineItemDao().insert(item)
                    AlarmScheduler.schedule(context, item.copy(id = id.toInt()))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
