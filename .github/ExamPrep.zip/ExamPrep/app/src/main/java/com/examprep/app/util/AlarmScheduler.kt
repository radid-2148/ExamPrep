package com.examprep.app.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.examprep.app.data.RoutineItem
import com.examprep.app.receiver.AlarmReceiver
import java.util.Calendar

object AlarmScheduler {

    /** Schedules (or reschedules) the next occurrence for this routine item. */
    fun schedule(context: Context, item: RoutineItem) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = buildPendingIntent(context, item)

        val triggerTime = nextTriggerMillis(item)
        try {
            alarmManager.setAlarmClock(
                AlarmManager.AlarmClockInfo(triggerTime, pendingIntent),
                pendingIntent
            )
        } catch (e: SecurityException) {
            // SCHEDULE_EXACT_ALARM not granted on this Android version; fall back
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        }
    }

    fun cancel(context: Context, item: RoutineItem) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(buildPendingIntent(context, item))
    }

    private fun buildPendingIntent(context: Context, item: RoutineItem): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("title", item.title)
        }
        return PendingIntent.getBroadcast(
            context,
            item.requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Finds the next matching day-of-week + time from now. */
    private fun nextTriggerMillis(item: RoutineItem): Long {
        val days = item.daysOfWeek.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
        val now = Calendar.getInstance()

        for (dayOffset in 0..7) {
            val candidate = Calendar.getInstance()
            candidate.add(Calendar.DAY_OF_YEAR, dayOffset)
            candidate.set(Calendar.HOUR_OF_DAY, item.hour)
            candidate.set(Calendar.MINUTE, item.minute)
            candidate.set(Calendar.SECOND, 0)
            candidate.set(Calendar.MILLISECOND, 0)

            val dayOfWeek = candidate.get(Calendar.DAY_OF_WEEK) // Sun=1..Sat=7
            val matchesDay = days.isEmpty() || dayOfWeek in days
            if (matchesDay && candidate.after(now)) {
                return candidate.timeInMillis
            }
        }
        // fallback: tomorrow same time
        val fallback = Calendar.getInstance()
        fallback.add(Calendar.DAY_OF_YEAR, 1)
        fallback.set(Calendar.HOUR_OF_DAY, item.hour)
        fallback.set(Calendar.MINUTE, item.minute)
        return fallback.timeInMillis
    }
}
