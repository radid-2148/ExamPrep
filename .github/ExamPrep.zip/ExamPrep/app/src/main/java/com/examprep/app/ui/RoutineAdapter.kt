package com.examprep.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.examprep.app.data.RoutineItem
import com.examprep.app.databinding.ItemRoutineBinding
import com.examprep.app.util.DateUtils

class RoutineAdapter(
    private var items: List<RoutineItem> = emptyList(),
    private val onToggle: (RoutineItem, Boolean) -> Unit,
    private val onLongClick: (RoutineItem) -> Unit
) : RecyclerView.Adapter<RoutineAdapter.VH>() {

    fun submitList(newItems: List<RoutineItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemRoutineBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size

    inner class VH(private val binding: ItemRoutineBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: RoutineItem) {
            binding.textRoutineTitle.text = item.title
            binding.textRoutineTime.text = DateUtils.formatTime(item.hour, item.minute)
            binding.switchRoutineEnabled.setOnCheckedChangeListener(null)
            binding.switchRoutineEnabled.isChecked = item.alarmEnabled
            binding.switchRoutineEnabled.setOnCheckedChangeListener { _, isChecked ->
                onToggle(item, isChecked)
            }
            binding.root.setOnLongClickListener { onLongClick(item); true }
        }
    }
}
