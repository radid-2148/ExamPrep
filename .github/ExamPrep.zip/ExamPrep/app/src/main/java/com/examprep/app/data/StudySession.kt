package com.examprep.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val startMillis: Long,
    val durationMinutes: Int,
    val dateLabel: String
)
