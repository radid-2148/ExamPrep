package com.examprep.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.examprep.app.data.Exam
import com.examprep.app.databinding.ItemExamBinding
import com.examprep.app.util.DateUtils

class ExamAdapter(
    private var exams: List<Exam> = emptyList(),
    private val onClick: (Exam) -> Unit,
    private val onLongClick: (Exam) -> Unit
) : RecyclerView.Adapter<ExamAdapter.ExamViewHolder>() {

    fun submitList(newExams: List<Exam>) {
        exams = newExams
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExamViewHolder {
        val binding = ItemExamBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ExamViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExamViewHolder, position: Int) {
        holder.bind(exams[position])
    }

    override fun getItemCount() = exams.size

    inner class ExamViewHolder(private val binding: ItemExamBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(exam: Exam) {
            binding.textExamName.text = exam.name
            binding.textUniversity.text = exam.university
            val days = DateUtils.daysUntil(exam.examDateMillis)
            binding.textDaysLeft.text = when {
                days < 0 -> "Passed"
                days == 0L -> "Today!"
                else -> "$days days left"
            }
            binding.textExamDate.text = DateUtils.formatDate(exam.examDateMillis)
            binding.root.setOnClickListener { onClick(exam) }
            binding.root.setOnLongClickListener { onLongClick(exam); true }
        }
    }
}
