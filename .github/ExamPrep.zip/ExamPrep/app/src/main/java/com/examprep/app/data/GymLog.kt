package com.examprep.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "gym_logs")
data class GymLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dateLabel: String,
    val activity: String,
    val durationMinutes: Int
)
