package com.examprep.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "syllabus_topics")
data class SyllabusTopic(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val examId: Int,
    val topicName: String,
    val isDone: Boolean = false
)
