package com.examprep.app.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Lightweight synchronous store used by the Accessibility Service
 * (which cannot easily use suspend/Room calls on its callback thread)
 * and by the UI to configure blocking + focus mode + streaks.
 */
object Prefs {
    private const val FILE = "examprep_prefs"
    private const val KEY_BLOCKED_APPS = "blocked_apps" // comma separated package names
    private const val KEY_STUDY_MODE_ON = "study_mode_on"
    private const val KEY_DND_WITH_STUDY = "dnd_with_study"
    private const val KEY_STREAK_COUNT = "streak_count"
    private const val KEY_LAST_STUDY_DATE = "last_study_date"

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getBlockedApps(context: Context): Set<String> {
        val raw = prefs(context).getString(KEY_BLOCKED_APPS, "") ?: ""
        return raw.split(",").filter { it.isNotBlank() }.toSet()
    }

    fun setBlockedApps(context: Context, packages: Set<String>) {
        prefs(context).edit().putString(KEY_BLOCKED_APPS, packages.joinToString(",")).apply()
    }

    fun addBlockedApp(context: Context, packageName: String) {
        val current = getBlockedApps(context).toMutableSet()
        current.add(packageName)
        setBlockedApps(context, current)
    }

    fun removeBlockedApp(context: Context, packageName: String) {
        val current = getBlockedApps(context).toMutableSet()
        current.remove(packageName)
        setBlockedApps(context, current)
    }

    fun isStudyModeOn(context: Context): Boolean =
        prefs(context).getBoolean(KEY_STUDY_MODE_ON, false)

    fun setStudyModeOn(context: Context, on: Boolean) {
        prefs(context).edit().putBoolean(KEY_STUDY_MODE_ON, on).apply()
    }

    fun shouldEnableDndWithStudy(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DND_WITH_STUDY, true)

    fun setEnableDndWithStudy(context: Context, on: Boolean) {
        prefs(context).edit().putBoolean(KEY_DND_WITH_STUDY, on).apply()
    }

    fun getStreak(context: Context): Int = prefs(context).getInt(KEY_STREAK_COUNT, 0)

    /** Call once per day when the user logs any study time. Bumps or resets streak. */
    fun registerStudyToday(context: Context, todayLabel: String) {
        val p = prefs(context)
        val last = p.getString(KEY_LAST_STUDY_DATE, null)
        if (last == todayLabel) return // already counted today
        val yesterday = DateUtils.previousDateLabel(todayLabel)
        val newStreak = if (last == yesterday) getStreak(context) + 1 else 1
        p.edit()
            .putInt(KEY_STREAK_COUNT, newStreak)
            .putString(KEY_LAST_STUDY_DATE, todayLabel)
            .apply()
    }
}
