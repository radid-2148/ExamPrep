package com.examprep.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sleep_logs")
data class SleepLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dateLabel: String,
    val sleepStartMillis: Long,
    val sleepEndMillis: Long,
    val hours: Float
)
