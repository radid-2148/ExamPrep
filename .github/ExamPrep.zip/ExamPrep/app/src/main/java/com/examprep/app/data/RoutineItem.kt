package com.examprep.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "routine_items")
data class RoutineItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val hour: Int,
    val minute: Int,
    val daysOfWeek: String,
    val alarmEnabled: Boolean = true,
    val requestCode: Int = 0
)
