package com.examprep.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.examprep.app.ui.AlarmRingActivity

/**
 * Fired by AlarmManager at the scheduled routine time. Launches the
 * full-screen ringing activity (works even over the lock screen).
 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Routine reminder"
        val launch = Intent(context, AlarmRingActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("title", title)
        }
        context.startActivity(launch)
    }
}
