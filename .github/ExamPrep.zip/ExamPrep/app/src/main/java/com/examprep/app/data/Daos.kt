package com.examprep.app.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface ExamDao {
    @Query("SELECT * FROM exams ORDER BY examDateMillis ASC")
    fun getAll(): LiveData<List<Exam>>

    @Query("SELECT * FROM exams ORDER BY examDateMillis ASC")
    suspend fun getAllOnce(): List<Exam>

    @Insert
    suspend fun insert(exam: Exam): Long

    @Update
    suspend fun update(exam: Exam)

    @Delete
    suspend fun delete(exam: Exam)
}

@Dao
interface StudySessionDao {
    @Query("SELECT * FROM study_sessions ORDER BY startMillis DESC")
    fun getAll(): LiveData<List<StudySession>>

    @Query("SELECT * FROM study_sessions WHERE dateLabel = :date")
    suspend fun getForDate(date: String): List<StudySession>

    @Query("SELECT dateLabel, SUM(durationMinutes) as total FROM study_sessions GROUP BY dateLabel ORDER BY dateLabel DESC LIMIT 7")
    fun getWeeklyTotals(): LiveData<List<DailyTotal>>

    @Insert
    suspend fun insert(session: StudySession)

    @Delete
    suspend fun delete(session: StudySession)
}

data class DailyTotal(val dateLabel: String, val total: Int)

@Dao
interface SleepLogDao {
    @Query("SELECT * FROM sleep_logs ORDER BY sleepStartMillis DESC")
    fun getAll(): LiveData<List<SleepLog>>

    @Insert
    suspend fun insert(log: SleepLog)

    @Delete
    suspend fun delete(log: SleepLog)
}

@Dao
interface GymLogDao {
    @Query("SELECT * FROM gym_logs ORDER BY id DESC")
    fun getAll(): LiveData<List<GymLog>>

    @Insert
    suspend fun insert(log: GymLog)

    @Delete
    suspend fun delete(log: GymLog)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedMillis DESC")
    fun getAll(): LiveData<List<Note>>

    @Insert
    suspend fun insert(note: Note)

    @Update
    suspend fun update(note: Note)

    @Delete
    suspend fun delete(note: Note)
}

@Dao
interface RoutineItemDao {
    @Query("SELECT * FROM routine_items ORDER BY hour ASC, minute ASC")
    fun getAll(): LiveData<List<RoutineItem>>

    @Query("SELECT * FROM routine_items ORDER BY hour ASC, minute ASC")
    suspend fun getAllOnce(): List<RoutineItem>

    @Insert
    suspend fun insert(item: RoutineItem): Long

    @Update
    suspend fun update(item: RoutineItem)

    @Delete
    suspend fun delete(item: RoutineItem)
}

@Dao
interface SyllabusTopicDao {
    @Query("SELECT * FROM syllabus_topics WHERE examId = :examId")
    fun getForExam(examId: Int): LiveData<List<SyllabusTopic>>

    @Insert
    suspend fun insert(topic: SyllabusTopic)

    @Update
    suspend fun update(topic: SyllabusTopic)

    @Delete
    suspend fun delete(topic: SyllabusTopic)
}

@Dao
interface MockTestScoreDao {
    @Query("SELECT * FROM mock_test_scores WHERE examId = :examId ORDER BY dateMillis ASC")
    fun getForExam(examId: Int): LiveData<List<MockTestScore>>

    @Insert
    suspend fun insert(score: MockTestScore)

    @Delete
    suspend fun delete(score: MockTestScore)
}
