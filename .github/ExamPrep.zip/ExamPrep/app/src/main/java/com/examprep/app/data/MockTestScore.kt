package com.examprep.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mock_test_scores")
data class MockTestScore(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val examId: Int,
    val testName: String,
    val score: Float,
    val outOf: Float,
    val dateMillis: Long
)
