package com.examprep.app.ui

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.examprep.app.databinding.ItemInstalledAppBinding

data class InstalledAppRow(val appInfo: ApplicationInfo, val label: String, val packageName: String)

class InstalledAppAdapter(
    private val packageManager: PackageManager,
    private var apps: List<InstalledAppRow> = emptyList(),
    private var blockedPackages: Set<String> = emptySet(),
    private val onToggle: (String, Boolean) -> Unit
) : RecyclerView.Adapter<InstalledAppAdapter.VH>() {

    fun submitList(newApps: List<InstalledAppRow>, blocked: Set<String>) {
        apps = newApps
        blockedPackages = blocked
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemInstalledAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(apps[position])
    override fun getItemCount() = apps.size

    inner class VH(private val binding: ItemInstalledAppBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(row: InstalledAppRow) {
            binding.textAppName.text = row.label
            binding.imageAppIcon.setImageDrawable(row.appInfo.loadIcon(packageManager))
            binding.switchBlocked.setOnCheckedChangeListener(null)
            binding.switchBlocked.isChecked = row.packageName in blockedPackages
            binding.switchBlocked.setOnCheckedChangeListener { _, checked ->
                onToggle(row.packageName, checked)
            }
        }
    }
}
