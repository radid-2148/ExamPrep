package com.examprep.app.ui

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.examprep.app.data.AppDatabase
import com.examprep.app.data.Exam
import com.examprep.app.databinding.DialogAddExamBinding
import com.examprep.app.databinding.FragmentExamsBinding
import kotlinx.coroutines.launch
import java.util.Calendar

class ExamsFragment : Fragment() {

    private var _binding: FragmentExamsBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ExamAdapter
    private var pickedDateMillis: Long = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentExamsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val db = AppDatabase.getInstance(requireContext())

        adapter = ExamAdapter(
            onClick = { exam ->
                val intent = android.content.Intent(requireContext(), ExamDetailActivity::class.java)
                intent.putExtra("examId", exam.id)
                intent.putExtra("examName", exam.name)
                startActivity(intent)
            },
            onLongClick = { exam ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete ${exam.name}?")
                    .setPositiveButton("Delete") { _, _ ->
                        viewLifecycleOwner.lifecycleScope.launch { db.examDao().delete(exam) }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )
        binding.recyclerExams.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerExams.adapter = adapter

        db.examDao().getAll().observe(viewLifecycleOwner) { exams ->
            adapter.submitList(exams)
            binding.textEmpty.visibility = if (exams.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.fabAddExam.setOnClickListener { showAddExamDialog(db) }
    }

    private fun showAddExamDialog(db: AppDatabase) {
        val dialogBinding = DialogAddExamBinding.inflate(LayoutInflater.from(requireContext()))
        pickedDateMillis = 0

        dialogBinding.buttonPickDate.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(
                requireContext(),
                { _, year, month, day ->
                    val picked = Calendar.getInstance()
                    picked.set(year, month, day, 0, 0, 0)
                    pickedDateMillis = picked.timeInMillis
                    dialogBinding.buttonPickDate.text = "Date: ${month + 1}/$day/$year"
                },
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Add exam")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val name = dialogBinding.editExamName.text.toString().trim()
                val uni = dialogBinding.editUniversity.text.toString().trim()
                if (name.isEmpty() || pickedDateMillis == 0L) {
                    Toast.makeText(requireContext(), "Enter a name and pick a date", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewLifecycleOwner.lifecycleScope.launch {
                    db.examDao().insert(Exam(name = name, university = uni, examDateMillis = pickedDateMillis))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
