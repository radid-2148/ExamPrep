package com.examprep.app.ui

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.examprep.app.R
import com.examprep.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val dashboardFragment = DashboardFragment()
    private val examsFragment = ExamsFragment()
    private val trackerFragment = TrackerFragment()
    private val notesFragment = NotesFragment()
    private val routineFragment = RoutineFragment()
    private val blockerFragment = BlockerSettingsFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestRuntimeNotificationPermission()

        if (savedInstanceState == null) {
            showFragment(dashboardFragment)
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> showFragment(dashboardFragment)
                R.id.nav_exams -> showFragment(examsFragment)
                R.id.nav_tracker -> showFragment(trackerFragment)
                R.id.nav_notes -> showFragment(notesFragment)
                R.id.nav_routine -> showFragment(routineFragment)
                R.id.nav_blocker -> showFragment(blockerFragment)
            }
            true
        }
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private fun requestRuntimeNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                101
            )
        }
    }
}
