package com.examprep.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Exam::class,
        StudySession::class,
        SleepLog::class,
        GymLog::class,
        Note::class,
        RoutineItem::class,
        SyllabusTopic::class,
        MockTestScore::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun examDao(): ExamDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun sleepLogDao(): SleepLogDao
    abstract fun gymLogDao(): GymLogDao
    abstract fun noteDao(): NoteDao
    abstract fun routineItemDao(): RoutineItemDao
    abstract fun syllabusTopicDao(): SyllabusTopicDao
    abstract fun mockTestScoreDao(): MockTestScoreDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "examprep.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
