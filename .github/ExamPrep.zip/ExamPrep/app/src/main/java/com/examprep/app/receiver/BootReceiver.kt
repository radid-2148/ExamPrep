package com.examprep.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.examprep.app.data.AppDatabase
import com.examprep.app.util.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Reschedules all routine alarms after the phone reboots, since
 * AlarmManager alarms don't survive a restart on their own.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            val items = AppDatabase.getInstance(appContext).routineItemDao().getAllOnce()
            items.filter { it.alarmEnabled }.forEach { item ->
                AlarmScheduler.schedule(appContext, item)
            }
        }
    }
}
