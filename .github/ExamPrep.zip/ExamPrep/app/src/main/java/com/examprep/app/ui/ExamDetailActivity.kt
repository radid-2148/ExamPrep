package com.examprep.app.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.examprep.app.R
import com.examprep.app.data.AppDatabase
import com.examprep.app.data.MockTestScore
import com.examprep.app.data.SyllabusTopic
import com.examprep.app.databinding.ActivityExamDetailBinding
import com.examprep.app.databinding.ItemSyllabusTopicBinding
import kotlinx.coroutines.launch

class ExamDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityExamDetailBinding
    private var examId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExamDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        examId = intent.getIntExtra("examId", -1)
        title = intent.getStringExtra("examName") ?: "Exam"
        val db = AppDatabase.getInstance(this)

        val topicAdapter = SyllabusAdapter(
            onToggle = { topic, done ->
                lifecycleScope.launch { db.syllabusTopicDao().update(topic.copy(isDone = done)) }
            }
        )
        binding.recyclerSyllabus.layoutManager = LinearLayoutManager(this)
        binding.recyclerSyllabus.adapter = topicAdapter

        db.syllabusTopicDao().getForExam(examId).observe(this) { topics ->
            topicAdapter.submitList(topics)
            val done = topics.count { it.isDone }
            binding.textSyllabusProgress.text = "$done / ${topics.size} topics done"
        }

        db.mockTestScoreDao().getForExam(examId).observe(this) { scores ->
            if (scores.isEmpty()) {
                binding.textMockAverage.text = "No mock tests logged yet"
            } else {
                val avgPercent = scores.map { it.score / it.outOf * 100 }.average()
                binding.textMockAverage.text = "Average: %.1f%% over ${scores.size} test(s)".format(avgPercent)
            }
        }

        binding.buttonAddTopic.setOnClickListener {
            val input = EditText(this).apply { hint = "Topic name" }
            AlertDialog.Builder(this)
                .setTitle("Add syllabus topic")
                .setView(input)
                .setPositiveButton("Add") { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isNotEmpty()) {
                        lifecycleScope.launch {
                            db.syllabusTopicDao().insert(SyllabusTopic(examId = examId, topicName = name))
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.buttonAddMockScore.setOnClickListener {
            val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val nameInput = EditText(this).apply { hint = "Test name" }
            val scoreInput = EditText(this).apply {
                hint = "Score obtained"
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            val outOfInput = EditText(this).apply {
                hint = "Out of"
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            layout.addView(nameInput); layout.addView(scoreInput); layout.addView(outOfInput)

            AlertDialog.Builder(this)
                .setTitle("Log mock test score")
                .setView(layout)
                .setPositiveButton("Save") { _, _ ->
                    val score = scoreInput.text.toString().toFloatOrNull()
                    val outOf = outOfInput.text.toString().toFloatOrNull()
                    if (score == null || outOf == null || outOf <= 0f) {
                        Toast.makeText(this, "Enter valid numbers", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                    lifecycleScope.launch {
                        db.mockTestScoreDao().insert(
                            MockTestScore(
                                examId = examId,
                                testName = nameInput.text.toString().ifBlank { "Mock test" },
                                score = score,
                                outOf = outOf,
                                dateMillis = System.currentTimeMillis()
                            )
                        )
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}

class SyllabusAdapter(
    private var topics: List<SyllabusTopic> = emptyList(),
    private val onToggle: (SyllabusTopic, Boolean) -> Unit
) : RecyclerView.Adapter<SyllabusAdapter.VH>() {

    fun submitList(newTopics: List<SyllabusTopic>) {
        topics = newTopics
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
        val binding = ItemSyllabusTopicBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(topics[position])
    override fun getItemCount() = topics.size

    inner class VH(private val binding: ItemSyllabusTopicBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(topic: SyllabusTopic) {
            binding.checkboxTopic.setOnCheckedChangeListener(null)
            binding.checkboxTopic.text = topic.topicName
            binding.checkboxTopic.isChecked = topic.isDone
            binding.checkboxTopic.setOnCheckedChangeListener { _, isChecked ->
                onToggle(topic, isChecked)
            }
        }
    }
}
