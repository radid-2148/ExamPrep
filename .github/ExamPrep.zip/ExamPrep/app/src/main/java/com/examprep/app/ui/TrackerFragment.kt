package com.examprep.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.examprep.app.data.AppDatabase
import com.examprep.app.data.GymLog
import com.examprep.app.data.SleepLog
import com.examprep.app.data.StudySession
import com.examprep.app.databinding.FragmentTrackerBinding
import com.examprep.app.util.DateUtils
import com.examprep.app.util.Prefs
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.launch

class TrackerFragment : Fragment() {

    private var _binding: FragmentTrackerBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTrackerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val context = requireContext()
        val db = AppDatabase.getInstance(context)

        // ---- Study session logging ----
        binding.buttonLogStudy.setOnClickListener {
            val subject = binding.editStudySubject.text.toString().trim().ifBlank { "General" }
            val minutes = binding.editStudyMinutes.text.toString().toIntOrNull()
            if (minutes == null || minutes <= 0) {
                Toast.makeText(context, "Enter valid minutes", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewLifecycleOwner.lifecycleScope.launch {
                db.studySessionDao().insert(
                    StudySession(
                        subject = subject,
                        startMillis = System.currentTimeMillis(),
                        durationMinutes = minutes,
                        dateLabel = DateUtils.todayLabel()
                    )
                )
                Prefs.registerStudyToday(context, DateUtils.todayLabel())
                binding.editStudySubject.text.clear()
                binding.editStudyMinutes.text.clear()
                Toast.makeText(context, "Logged $minutes min of $subject", Toast.LENGTH_SHORT).show()
            }
        }

        // ---- Sleep logging ----
        binding.buttonLogSleep.setOnClickListener {
            val hours = binding.editSleepHours.text.toString().toFloatOrNull()
            if (hours == null || hours <= 0f) {
                Toast.makeText(context, "Enter valid hours", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewLifecycleOwner.lifecycleScope.launch {
                val now = System.currentTimeMillis()
                db.sleepLogDao().insert(
                    SleepLog(
                        dateLabel = DateUtils.todayLabel(),
                        sleepStartMillis = now - (hours * 3600_000).toLong(),
                        sleepEndMillis = now,
                        hours = hours
                    )
                )
                binding.editSleepHours.text.clear()
                Toast.makeText(context, "Logged $hours h sleep", Toast.LENGTH_SHORT).show()
            }
        }

        // ---- Gym logging ----
        binding.buttonLogGym.setOnClickListener {
            val activity = binding.editGymActivity.text.toString().trim().ifBlank { "Workout" }
            val minutes = binding.editGymMinutes.text.toString().toIntOrNull()
            if (minutes == null || minutes <= 0) {
                Toast.makeText(context, "Enter valid minutes", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewLifecycleOwner.lifecycleScope.launch {
                db.gymLogDao().insert(
                    GymLog(dateLabel = DateUtils.todayLabel(), activity = activity, durationMinutes = minutes)
                )
                binding.editGymActivity.text.clear()
                binding.editGymMinutes.text.clear()
                Toast.makeText(context, "Logged $activity", Toast.LENGTH_SHORT).show()
            }
        }

        // ---- Weekly study chart ----
        db.studySessionDao().getWeeklyTotals().observe(viewLifecycleOwner) { totals ->
            val sorted = totals.sortedBy { it.dateLabel }
            val entries = sorted.mapIndexed { index, t -> BarEntry(index.toFloat(), t.total.toFloat()) }
            val labels = sorted.map { it.dateLabel.takeLast(5) }

            val dataSet = BarDataSet(entries, "Minutes studied")
            binding.chartWeeklyStudy.data = BarData(dataSet)
            binding.chartWeeklyStudy.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
            binding.chartWeeklyStudy.xAxis.position = XAxis.XAxisPosition.BOTTOM
            binding.chartWeeklyStudy.description.isEnabled = false
            binding.chartWeeklyStudy.invalidate()
        }

        db.sleepLogDao().getAll().observe(viewLifecycleOwner) { logs ->
            val last = logs.firstOrNull()
            binding.textLastSleep.text = if (last != null) "Last sleep: ${last.hours} h" else "No sleep logged yet"
        }

        db.gymLogDao().getAll().observe(viewLifecycleOwner) { logs ->
            val last = logs.firstOrNull()
            binding.textLastGym.text = if (last != null) "Last workout: ${last.activity} (${last.durationMinutes} min)" else "No workouts logged yet"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
