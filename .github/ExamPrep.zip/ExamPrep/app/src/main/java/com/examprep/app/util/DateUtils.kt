package com.examprep.app.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object DateUtils {
    private val dayFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun todayLabel(): String = dayFormat.format(Date())

    fun labelFor(millis: Long): String = dayFormat.format(Date(millis))

    fun previousDateLabel(label: String): String {
        val date = dayFormat.parse(label) ?: return label
        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_YEAR, -1)
        return dayFormat.format(cal.time)
    }

    /** Days left until a target date (>= 0), based on calendar days, not exact hours. */
    fun daysUntil(targetMillis: Long): Long {
        val now = Calendar.getInstance()
        now.set(Calendar.HOUR_OF_DAY, 0); now.set(Calendar.MINUTE, 0)
        now.set(Calendar.SECOND, 0); now.set(Calendar.MILLISECOND, 0)

        val target = Calendar.getInstance()
        target.timeInMillis = targetMillis
        target.set(Calendar.HOUR_OF_DAY, 0); target.set(Calendar.MINUTE, 0)
        target.set(Calendar.SECOND, 0); target.set(Calendar.MILLISECOND, 0)

        val diff = target.timeInMillis - now.timeInMillis
        return TimeUnit.MILLISECONDS.toDays(diff)
    }

    fun formatDate(millis: Long): String {
        val fmt = SimpleDateFormat("dd MMM yyyy", Locale.US)
        return fmt.format(Date(millis))
    }

    fun formatTime(hour: Int, minute: Int): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        val fmt = SimpleDateFormat("hh:mm a", Locale.US)
        return fmt.format(cal.time)
    }
}
