package com.examprep.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.examprep.app.R
import com.examprep.app.data.AppDatabase
import com.examprep.app.util.DateUtils

/**
 * Runs once a day and posts one notification per upcoming exam showing
 * how many days are left. Scheduled as a periodic WorkManager job.
 */
class DailyReminderWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.getInstance(applicationContext)
        val exams = db.examDao().getAllOnce()
        if (exams.isEmpty()) return Result.success()

        ensureChannel()
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        exams.forEachIndexed { index, exam ->
            val daysLeft = DateUtils.daysUntil(exam.examDateMillis)
            if (daysLeft < 0) return@forEachIndexed
            val text = when {
                daysLeft == 0L -> "${exam.name} is TODAY. All the best!"
                daysLeft == 1L -> "${exam.name} is tomorrow \u2013 ${daysLeft} day left."
                else -> "${exam.name}: $daysLeft days left."
            }
            val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Exam Countdown")
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            nm.notify(1000 + exam.id, notification)
        }
        return Result.success()
    }

    private fun ensureChannel() {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID, "Exam Countdown", NotificationManager.IMPORTANCE_DEFAULT
        )
        nm.createNotificationChannel(channel)
    }

    companion object {
        const val CHANNEL_ID = "exam_countdown_channel"
        const val WORK_NAME = "daily_exam_reminder"
    }
}
