package com.examprep.app.ui

import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.examprep.app.data.AppDatabase
import com.examprep.app.databinding.FragmentDashboardBinding
import com.examprep.app.util.DateUtils
import com.examprep.app.util.DndHelper
import com.examprep.app.util.Prefs
import kotlinx.coroutines.launch

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private var focusTimer: CountDownTimer? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val context = requireContext()
        val db = AppDatabase.getInstance(context)

        db.examDao().getAll().observe(viewLifecycleOwner) { exams ->
            val upcoming = exams.filter { DateUtils.daysUntil(it.examDateMillis) >= 0 }
                .minByOrNull { it.examDateMillis }
            if (upcoming != null) {
                val days = DateUtils.daysUntil(upcoming.examDateMillis)
                binding.textNearestExam.text = upcoming.name
                binding.textDaysLeft.text = "$days days left"
            } else {
                binding.textNearestExam.text = "No exams added yet"
                binding.textDaysLeft.text = "Add one from the Exams tab"
            }
        }

        binding.textStreak.text = "\uD83D\uDD25 ${Prefs.getStreak(context)}-day streak"

        binding.switchStudyMode.isChecked = Prefs.isStudyModeOn(context)
        binding.switchStudyMode.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setStudyModeOn(context, isChecked)
            if (isChecked) {
                Prefs.registerStudyToday(context, DateUtils.todayLabel())
                if (Prefs.shouldEnableDndWithStudy(context)) {
                    if (DndHelper.hasDndAccess(context)) {
                        DndHelper.enableDnd(context)
                    } else {
                        Toast.makeText(context, "Grant Do Not Disturb access in settings for auto-DND", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                if (Prefs.shouldEnableDndWithStudy(context)) DndHelper.disableDnd(context)
            }
        }

        binding.buttonFocus25.setOnClickListener { startFocusSession(25) }
        binding.buttonFocus50.setOnClickListener { startFocusSession(50) }

        binding.buttonOpenAccessibility.setOnClickListener {
            startActivity(android.content.Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.buttonOpenDndAccess.setOnClickListener {
            startActivity(android.content.Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }

    /** Pomodoro-style focus session: turns study mode + DND on for N minutes, then off. */
    private fun startFocusSession(minutes: Int) {
        val context = requireContext()
        focusTimer?.cancel()
        binding.switchStudyMode.isChecked = true // triggers listener -> enables blocking + DND

        binding.textFocusCountdown.visibility = View.VISIBLE
        focusTimer = object : CountDownTimer(minutes * 60_000L, 1000L) {
            override fun onTick(msLeft: Long) {
                val m = (msLeft / 1000) / 60
                val s = (msLeft / 1000) % 60
                binding.textFocusCountdown.text = String.format("Focus ends in %02d:%02d", m, s)
            }

            override fun onFinish() {
                binding.textFocusCountdown.visibility = View.GONE
                binding.switchStudyMode.isChecked = false // triggers listener -> disables blocking + DND
                Toast.makeText(context, "Focus session complete. Great work!", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        focusTimer?.cancel()
        _binding = null
    }
}
