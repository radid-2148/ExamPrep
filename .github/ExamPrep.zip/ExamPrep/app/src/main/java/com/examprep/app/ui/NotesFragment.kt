package com.examprep.app.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.examprep.app.data.AppDatabase
import com.examprep.app.data.Note
import com.examprep.app.databinding.DialogAddNoteBinding
import com.examprep.app.databinding.FragmentNotesBinding
import kotlinx.coroutines.launch

class NotesFragment : Fragment() {

    private var _binding: FragmentNotesBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: NoteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val db = AppDatabase.getInstance(requireContext())

        adapter = NoteAdapter(
            onClick = { note -> showNoteDialog(db, note) },
            onLongClick = { note ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete note?")
                    .setPositiveButton("Delete") { _, _ ->
                        viewLifecycleOwner.lifecycleScope.launch { db.noteDao().delete(note) }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )
        binding.recyclerNotes.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerNotes.adapter = adapter

        db.noteDao().getAll().observe(viewLifecycleOwner) { notes ->
            adapter.submitList(notes)
            binding.textEmptyNotes.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.fabAddNote.setOnClickListener { showNoteDialog(db, null) }
    }

    private fun showNoteDialog(db: AppDatabase, existing: Note?) {
        val dialogBinding = DialogAddNoteBinding.inflate(LayoutInflater.from(requireContext()))
        existing?.let {
            dialogBinding.editNoteTitle.setText(it.title)
            dialogBinding.editNoteSubject.setText(it.subject)
            dialogBinding.editNoteContent.setText(it.content)
        }

        AlertDialog.Builder(requireContext())
            .setTitle(if (existing == null) "New note" else "Edit note")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val title = dialogBinding.editNoteTitle.text.toString().trim()
                val subject = dialogBinding.editNoteSubject.text.toString().trim().ifBlank { "General" }
                val content = dialogBinding.editNoteContent.text.toString()
                if (title.isEmpty()) {
                    Toast.makeText(requireContext(), "Enter a title", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewLifecycleOwner.lifecycleScope.launch {
                    if (existing == null) {
                        db.noteDao().insert(
                            Note(title = title, subject = subject, content = content, updatedMillis = System.currentTimeMillis())
                        )
                    } else {
                        db.noteDao().update(
                            existing.copy(title = title, subject = subject, content = content, updatedMillis = System.currentTimeMillis())
                        )
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
